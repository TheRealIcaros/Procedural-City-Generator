Hur applikationen fungerar

Knappar:
W = flyttar kameran fram�t
A = flyttar kameran �t v�nster
S = flyttar kameran bak�t
D = flyttar kameran �t h�ger
Musen = �ndrar kamerans synf�lt
F1 = �ppnar menyn f�r att generera en ny stad
alt = m�ste h�llas nere f�r att kunna interagera med menyn n�r den �r framme
Esc = st�nger av applikationen